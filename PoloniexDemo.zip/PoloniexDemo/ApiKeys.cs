﻿namespace PoloniexDemo
{
    struct ApiKeys
    {
        //Me
        internal const string PublicKey = "E88YLO33-N5U8AZE7-1EBCSROU-KRKO39N7";
        internal const string PrivateKey = "e8e93bd6a4c11d46bf5e11b42269a2b8ca9e1350a06466e279241ba24ddd9468e59293ca77b994582f7171e303d026771e083dcfdc7c3da8e8b244e75519eb95";

        //Jay
        //internal const string PublicKey = "RBXRL9WO-B69IFPHZ-BWA5S0U3-UV5MRQK8";
        //internal const string PrivateKey = "4745c5b4811730d9852ae61871903c407bf132c5e1f085d2fb49577440bc09f49b17ca349edf1a9ed67b04c0bcd99e76bc0f2dc516e07571743fcfb8eb518b87";
    }
}
